package labyrinth;

/**
 * 
 * Cell Klasse beinhaltet alle relevanten Informationen zum Erstellen
 * und Navigieren des Labyrinths
 * 
 * @author Martin Schuster 
 * @version 1.0
 */

public class Cell {
	
	/*
	 * Relevante Variablen f�r die Erstellung des Labyrinths
	 * 
	 */
	private int cellRow; //Zeile der Zelle
	private int cellCol; //Spalte der Zelle
	private boolean[] walls = new boolean[4]; //Stelle an der die Zelle eine Wand hat oben, rechts, unten, links
	private boolean visited; //wurde die Zelle besucht relevant f�r die Erstellung des Labyrinths
	
	/*
	 * Relevante Variablen f�r die L�sung des Labyrinths
	 * 
	 */
	private int cost; //Kosten der Zelle um zum Zielpunkt zu gelangen
	private Cell parent; //Zelle von der die Aktuelle Zelle besucht wird
	private boolean path; //geh�rt die Aktuelle Zelle zum ziel Pfad
	private boolean deadend; //Ist die Aktuelle Zelle eine Sackgasse kosten sind geringer als andere Zelle aber kein erreichen des Zieles m�glich
	
	/**
	 * Konstruktor Neue Celle mit Standardwerten Initialisieren 
	 * 
	 * @param col Spalte der Zelle als int
	 * @param row Reihe der Zelle als int
	 */
	public Cell(int col, int row) {
		cellCol = col;
		cellRow = row;
		visited = false;
		cost = 0;
		parent=null;
		path=false;
		deadend = false;
		for(int i=0;i<walls.length;i++) {
			walls[i] = true;
		}
	}

	/*
	 * Getter und Setter f�r die Variablen
	 */
	
	/**
	 * Gibt an ob Zelle zum Ziel Pfad geh�rt
	 * @return true oder false 
	 */
	public boolean isPath() {
		return path;
	}

	/**
	 * Setzt den Status ob die Zelle zum Ziel Pfad geh�rt
	 * @param path bekommt einen true oder false Wert
	 */
	public void setPath(boolean path) {
		this.path = path;
	}

	/**
	 * Gibt die Reihe der Zelle zur�ck
	 * @return  Zeile als int Wert
	 */
	public int getRow() {
		return cellRow;
	}
	
	/**
	 * Gibt die Spalte der Zelle zur�ck
	 * @return Spalte als int Wert
	 */
	public int getCol() {
		return cellCol;
	}
	
	/**
	 * Gibt an ob die Zelle besucht wurde
	 * @return true oder false
	 */
	public boolean isVisited() {
		return visited;
	}
	
	/**
	 * Setzt den besucht Zustand der Zelle
	 * @param visit bekommt true oder false �bergeben
	 */
	public void setVisited(boolean visit) {
		visited = visit;
	}
	
	/**
	 * Setzt die W�nde der Zelle
	 * @param top obere Wand true oder false
	 * @param right rechte Wand true oder false
	 * @param bottom untere Wand true oder false
	 * @param left linke Wand true oder false
	 */
	public void setWalls(boolean top, boolean right, boolean bottom, boolean left) {
		walls[0] = top;
		walls[1] = right;
		walls[2] = bottom;
		walls[3] = left;
	}
	
	/**
	 * Setzt die obere Wand der Zelle
	 * @param top true oder false 
	 */
	public void setTopWall(boolean top) {
		walls[0] = top;
	}
	
	/**
	 * Setzt die untere Wand einer Zelle
	 * @param bottom true oder false
	 */
	public void setBottomWall(boolean bottom) {
		walls[2] = bottom;
	}
	
	/**
	 * Setzt die rechte Wand einer Zelle
	 * @param right true oder false
	 */
	public void setRightWall(boolean right) {
		walls[1] = right;
	}
	
	/**
	 * Setzt die linke Wand einer Zelle
	 * @param left true oder false
	 */
	public void setLeftWall(boolean left) {
		walls[3] = left;
	}
	
	/**
	 * Gibt die W�nde einer Zelle zur�ck
	 * @return boolean Array  mit true oder false Werten
	 */
	public boolean[] getwalls() {
		return walls;
	}

	/**
	 * Gibt die Kosten der Zelle zum Zielpunkt zur�ck
	 * @return Kosten als int Wert
	 */
	public int getCost() {
		return cost;
	}

	/**
	 * Setzt die Kosten der Zelle zum Zielpunkt
	 * @param cost Kosten als int Wert
	 */
	public void setCost(int cost) {
		this.cost = cost;
	}

	/**
	 * Gibt die Vorg�nger Zelle der aktuellen Zelle zur�ck
	 * @return Vorg�nger Zelle typ Cell
	 */
	public Cell getParent() {
		return parent;
	}

	/**
	 * Setzt die Vorg�nger Zelle der aktuellen Zelle
	 * @param parent Vorg�nger Zelle typ Cell
	 */
	public void setParent(Cell parent) {
		this.parent = parent;
	}

	/**
	 * Gibt an ob die aktuelle Zelle eine Sackgasse ist
	 * @return true oder false
	 */
	public boolean isDeadend() {
		return deadend;
	}

	/**
	 * Setzt die aktuelle Zelle als Sackgasse
	 * @param deadend true oder false
	 */
	public void setDeadend(boolean deadend) {
		this.deadend = deadend;
	}
}
