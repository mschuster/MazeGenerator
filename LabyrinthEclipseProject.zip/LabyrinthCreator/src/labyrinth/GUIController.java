package labyrinth;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Stack;
import java.util.concurrent.ThreadLocalRandom;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.paint.Color;

/**
 * GUIController Klasse 
 * Hauptklasse des Programms beinhaltet 3 Algorithmen 
 * Rekursive Backtracker und Rekursive Division zum Erstellen des Labyrinth
 * A-Stern zum L�sen 
 * 
 * @author Martin Schuster
 * @version 1.0
 */
public class GUIController implements Initializable {
	/*
	 * @FXML verwei�t auf die Elemente die im SceneBuilder angelegt wurden
	 * die eigenschaften der Elemente f�r das ausehen, Position usw werden aus der GUI.fxml datei entnommen
	 */
	@FXML
	private Canvas canvasLabGenerator;
	@FXML
	private Canvas canvasLabSolver;
	@FXML
	private Button generator;
	@FXML
	private Button solver;
	@FXML
	private RadioButton recursiveBacktracker;
	@FXML
	private RadioButton recursiveDivision;
	@FXML
	private Slider cellsizeSlider;
	@FXML
	private Label cellsizeCurrent;
	@FXML
	private Label solverResult;
	
	/*
	 * Allgemeine Variablen
	 */
	private int cols; //speichern der Spalten des Labyrinth
	private int rows; //speichern der Zeilen des Labyrinth
	private GraphicsContext gc; //wird jeweils einem der Canvas zugewiesen um dieses zu Bearbeiten
	private double cellsize; //Bestimmt die gr��e der Felder des Labyrinthes kann vom Nutzer festgelegt werden  
	private Cell[] grid; //Array f�r das Grid vom Typ Cell, Klasse Cell enth�lt alle Relevanten informationen eines Feldes wie Position besucht status usw.
	
	/*
	 * Variablen f�r den Rekursiv Backtrack Algorithmus
	 */
	private Stack<Cell> s = new Stack<Cell>(); 
	private Cell initialCell;
	private Cell currentCell;
	
	/*
	 * Variablen f�r den A-Stern Algorithmus
	 */
	private Stack<Cell> path = new Stack<Cell>();
	private Cell start;
	private Cell target;
	private final int gcost = 10;
	
	/*
	 * Dient dazu die beiden Canvas mit einem Rahmen zuversehen und die Fl�che weis zu f�rben
	 */
	
	/**
	 * initialize Methode setzt bei Programm beginn die beiden Canvas wei� und zeichnet einen schwarzen Rahmen
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		gc = canvasLabGenerator.getGraphicsContext2D();
		gc.setFill(Color.WHITE);
		gc.fillRect(snap(0), snap(0), snap(canvasLabGenerator.getWidth()), snap(canvasLabGenerator.getHeight()));
		gc.strokeRect(snap(0), snap(0), snap(canvasLabGenerator.getWidth()), snap(canvasLabGenerator.getHeight()));
		
		gc = canvasLabSolver.getGraphicsContext2D();
		gc.setFill(Color.WHITE);
		gc.fillRect(snap(0), snap(0), snap(canvasLabSolver.getWidth()), snap(canvasLabSolver.getHeight()));
		gc.strokeRect(snap(0), snap(0), snap(canvasLabSolver.getWidth()), snap(canvasLabSolver.getHeight()));
		solver.setDisable(true);
	}
	
	/**
	 * Initialisiert die Standardwerte 
	 */
	@FXML
	private void setup() {
		int width = (int) canvasLabGenerator.getWidth();
		int heigth = (int) canvasLabGenerator.getHeight();
		this.cellsize = (int) cellsizeSlider.getValue();
		solverResult.setText("");
		
		cellsizeCurrent.setText(String.valueOf(((int) cellsizeSlider.getValue())));
		rows = (int) (heigth/cellsize);
		cols = (int) (width/cellsize);
		grid = new Cell[rows*cols]; //gr��e des grid Arrays
		int count=0;
		
		//bef�lle Cell grid Array
		for(int y=0;y<rows;y++) {
			for(int x=0;x<cols;x++) {
				grid[count] = new Cell(x,y);
				count++;
			}	
		}
		
		if(recursiveDivision.isSelected()) {
			for(Cell c : grid) {
				c.setWalls(false, false, false, false);
			}
			
			for(Cell c : grid) {
				if(c.getRow()==0) {
					c.setTopWall(true);
				}
				if(c.getCol()==0) {
					c.setLeftWall(true);
				}
				if(c.getRow()==rows-1) {
					c.setBottomWall(true);
				}
				if(c.getCol()==cols-1) {
					c.setRightWall(true);
				}
			}
		}
	}
	
	/*
	 * Ausgef�hrt beim Anklicken des Generieren Buttons
	 * pr�ft welche erstell typ ausgew�hlt wurde und f�hrt daraufhin 
	 * den richtigen Algorithmus aus
	 */
	@FXML
	private void startGeneration() {
		gc = canvasLabGenerator.getGraphicsContext2D();
		gc.clearRect(snap(0), snap(0), snap(canvasLabGenerator.getWidth()), snap(canvasLabGenerator.getHeight()));
		
		setup();
		if(recursiveBacktracker.isSelected()) {
			backTrackerAlg();
		}else {
			divisionRecursive();
		}
		draw();
		gc =canvasLabSolver.getGraphicsContext2D();
		gc.clearRect(snap(0), snap(0), snap(canvasLabSolver.getWidth()), snap(canvasLabSolver.getHeight()));
		draw();
		gc.setFill(Color.AQUAMARINE);
		gc.fillOval(snap(0*cellsize), snap(0*cellsize), cellsize, cellsize);
		gc.setFill(Color.CORAL);
		gc.fillOval(snap((cols-1)*cellsize), snap((rows-1)*cellsize), cellsize, cellsize);
		solver.setDisable(false);
	}
	
	/*
	 * Pr�ft auf ver�nderung des Sliders f�r die Zelleng��e des Labyrinths
	 * setzt die neue gr��e auf das entsprechende Label
	 */
	@FXML
	private void changeSlider() {
		cellsizeSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
			   	cellsizeCurrent.setText(Integer.toString(newValue.intValue()));
			});
	}
	
	/**
	 * Der javafx renderer kann beim zeichnen von linien 
	 * ungenau werden und verurschacht ungleichm��ige linien st�rken.
	 * 
	 * L�sung von: http://dlsc.com/2014/04/10/javafx-tip-2-sharp-drawing-with-canvas-api/
	 * 
	 * Linie kann standartm��ig zwischen zwei Linien gezeichnet wodurch ein Dopplungseffect auftritt
	 * die snap Methode verschiebt die Linie um .5 Pixel und kann somit ein e scharfe linie zeichnen
	 * snap methode muss f�r jede Aktion mit Koordinaten genutzt werden um die Genauigkeit zu behalten
	 * 
	 * 
	 * @param axis Spalte oder Zeile 
	 * @return Spalte oder Zeile mit Offset von .5
	 */
	private double snap(double axis) {
	      return ((int) axis) + .5;
	}
	
	/**
	 * Ruft die Zeichenfunktion f�r die Zellenwerte das Labyrinth auf
	 */
	private void draw() {
		for(int i=0;i<grid.length;i++) {
			drawGridVisited(grid[i].getCol(), grid[i].getRow(), grid[i].getwalls(), Color.WHITE);
		}
	}
	
	/**
	 * Zeichnet die Zelle mit den dazugehr�igen W�nden
	 * 
	 * @param x Spalte
	 * @param y Zeile
	 * @param walls Array mit W�nden
	 * @param color m�glichkeit Farbe zu �bergeben
	 */
	private void drawGridVisited(double x, double y,boolean walls[], Color color) {
		gc.setFill(color);
		x=x*cellsize;
		y=y*cellsize;
		gc.fillRect(x, y, cellsize, cellsize);
		gc.setStroke(Color.BLACK);
		
		if(walls[0]) {
			gc.strokeLine(snap(x), snap(y), snap(x+cellsize), snap(y));
		}
		if(walls[1]) {
			gc.strokeLine(snap(x+cellsize), snap(y), snap(x+cellsize), snap(y+cellsize));
		}
		if(walls[2]) {
			gc.strokeLine(snap(x), snap(y+cellsize), snap(x+cellsize), snap(y+cellsize));
		}
		if(walls[3]) {
			gc.strokeLine(snap(x), snap(y), snap(x), snap(y+cellsize));
		}
		
	}
	
	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//######################################### Begin A*-Algrorithmus #####################################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
	/**
	 * startSolver startet den A*-Algorithmus welcher die Start Zelle und Ziel Zelle bestimmt und diese dem 
	 * astarAlgorithm �bergibt.
	 */
	@FXML
	private void startSolver() {
		path.clear();
		start = grid[0];
		target = grid[grid.length-1];
		astarAlgorithm(start, target); //Aufruf des A*-Algorithmus mit der Start und Ziel Zelle
		solver.setDisable(true); //Deaktiviert den L�sen Button nach dem L�sen eines Labyrinths
	}
	
	/**
	 * A*-Algorithmus 
	 * 
	 * @param start StartFeld an dem der Suchalgorithmus beginnt
	 * @param target ZielFeld welcher von dem StartFeld aus zu erreichen ist
	 */
	private void astarAlgorithm(Cell start, Cell target) {
		
		Cell next=null;
		next = nextField(start);
		start.setPath(true);
		path.push(start);		
		
		while(!path.isEmpty()) {
			path.push(next);
			next = nextField(next);
			if(next==target) {
				solverResult.setText("Pfad gefunden!");
				break;
			}
		}
		if(next==null ) {
			solverResult.setText("Kein Pfad gefunden!");
			return;
		}
		gc.setFill(Color.GOLD);
		for(int i=0;i<grid.length;i++) {
			if(grid[i].isPath()&&!grid[i].isDeadend()) {
				gc.fillOval(snap((grid[i].getCol()*cellsize)+((cellsize/2)/2)), snap((grid[i].getRow()*cellsize)+((cellsize/2)/2)), cellsize/2, cellsize/2);
			}
		}
	}
	
	/**
	 * Ermittelt die begehbaren felder um das aktuelle feld und ermittelt die Kosten von jedem feld zum ziel
	 * das feld mit den geringsten kosten wird als n�chstes feld bestimmt.
	 * 
	 * @param center Zelle um die gesucht wird
	 * @return Zelle mit den geringsten Kosten
	 */
	private Cell nextField(Cell center) {
		ArrayList<Cell> nextfields = new ArrayList<>();
		
		boolean walls[] = center.getwalls();
		
		for(int i=0;i<walls.length;i++) {
			if(walls[i]==false) {
				if(i==0 && grid[index(center.getCol(), center.getRow()-1)].getParent() == null) {
					nextfields.add(grid[index(center.getCol(), center.getRow()-1)]);
				}
				if(i==1 && grid[index(center.getCol()+1, center.getRow())].getParent() == null) {
					nextfields.add(grid[index(center.getCol()+1, center.getRow())]);
				}
				if(i==2 && grid[index(center.getCol(), center.getRow()+1)].getParent() == null) {
					nextfields.add(grid[index(center.getCol(), center.getRow()+1)]);
				}
				if(i==3 && grid[index(center.getCol()-1, center.getRow())].getParent() == null) {
					nextfields.add(grid[index(center.getCol()-1, center.getRow())]);
				}
			}
		}
		
		if(nextfields.isEmpty()) {
			center.setPath(false);
			center.setDeadend(true);
			Cell alt;
			
			alt = path.pop();
			center=alt;
			walls = alt.getwalls();
			
			while(nextfields.isEmpty()) {
				for(int i=0;i<walls.length;i++) {
					if(walls[i]==false) {
						if(i==0 && grid[index(alt.getCol(), alt.getRow()-1)].getParent() == null) {
							nextfields.add(grid[index(alt.getCol(), alt.getRow()-1)]);
						}
						if(i==1 && grid[index(alt.getCol()+1, alt.getRow())].getParent() == null) {
							nextfields.add(grid[index(center.getCol()+1, alt.getRow())]);
						}
						if(i==2 && grid[index(alt.getCol(), alt.getRow()+1)].getParent() == null) {
							nextfields.add(grid[index(alt.getCol(), alt.getRow()+1)]);
						}
						if(i==3 && grid[index(alt.getCol()-1, alt.getRow())].getParent() == null) {
							nextfields.add(grid[index(alt.getCol()-1, alt.getRow())]);
						}
					}
				}
				if(nextfields.isEmpty()) {
					alt.setDeadend(true);
					alt.setPath(false);
					if(!path.isEmpty()) {
						alt = path.pop();
						walls = alt.getwalls();
						center=alt;
					}else {
						return null;
					}
				}
			}
		}
		
		for(int i=0;i<nextfields.size();i++) {
			nextfields.get(i).setCost(manhattanHeuristik(nextfields.get(i), target));
		}
		
		int cost = Integer.MAX_VALUE;		
		int lowestCostItem=0;
		for(int i=0;i<nextfields.size();i++) {
			if(nextfields.get(i).getCost()<cost) {
				cost = nextfields.get(i).getCost();
				lowestCostItem = i;
			}
		}
		
		nextfields.get(lowestCostItem).setPath(true);
		nextfields.get(lowestCostItem).setParent(center);
		gc.setFill(Color.SLATEGREY);
		gc.fillOval(snap((nextfields.get(lowestCostItem).getCol()*cellsize)+((cellsize/2)/2)), snap((nextfields.get(lowestCostItem).getRow()*cellsize)+((cellsize/2)/2)), cellsize/2, cellsize/2);
		return nextfields.get(lowestCostItem);
	}
	
	/**
	 * Manhattan Heuristik ist eine m�glichkeit die entfernung von einem Punkt zum Ziel zu bestimmen 
	 * - Hindernisse werden ignoriert
	 * @param current Aktuellezelle von der die Kosten zum Zielberechnet werden
	 * @param target Zielzelle
	 * @return Kosten zum Ziel
	 */
	private int manhattanHeuristik(Cell current, Cell target) {
		return ( ( ( Math.abs(current.getCol() - target.getCol()) + Math.abs(current.getRow()-target.getRow()) ) * gcost ) + gcost);
	}
	
	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//########################################## Ende A*-Algrorithmus #####################################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
	
	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//######################################### Begin Rekursiv Backtracker#################################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
	/**
	 * Backtrack Algorithmus
	 * Feste StartZelle oben Links
	 * 
	 * Solange unbesuchte Zellen in dem grid Array vorhanden sind wird der Algorithmus ausgef�hrt.
	 * Von der Aktuellen Zelle aus werden alle unbesuchten Nachbar Zellen erfasst und zuf�llig aus diesen die n�chste Zelle ausgew�hlt.
	 * Im n�chsten Schritt wird die Wand zwischen beiden Zellen Entfernt.
	 * Die aktuelle Zelle wird auf den Stack verschoben und die geweh�lte n�chste Zelle zur aktuellen Zelle bestimmt.
	 * 
	 * Solange Wiederholt bis keine Nachbarn mehr gefunden Werden, dann wird der Stack r�ckw�rts abgearbeitet bis auch dieser Leer ist.
	 */
	private void backTrackerAlg() {
		initialCell= grid[0];
		s.clear();
		currentCell = initialCell;
		Cell next;
		currentCell.setVisited(true);
		
		while(unvisitedCells()) {
			next = findNeighbours(currentCell);
			if(next!=null) {
				next.setVisited(true);
				s.push(currentCell);
				removeWalls(currentCell, next);
				currentCell = next;
			}else if(s.size()>=0) {
				currentCell = s.pop();
			}
		}
	}
	
	/**
	 * Entfert die Wand Zwischen der aktuellen und der n�chsten Zelle
	 * @param current aktuelle Zelle
	 * @param next n�chste Zelle
	 */
	private void removeWalls(Cell current, Cell next) {
		
		int x = current.getCol() - next.getCol();

		if(x==1) {
			current.setLeftWall(false);
			next.setRightWall(false);
		}else if(x==-1) {
			current.setRightWall(false);
			next.setLeftWall(false);
		}
		
		int y = current.getRow() - next.getRow();
		
		if(y==1) {
			current.setTopWall(false);
			next.setBottomWall(false);
		}else if(y==-1){
			current.setBottomWall(false);
			next.setTopWall(false);
		}
	}
	
	/**
	 * Pr�ft nach jedem durchlauf das grid Array ob noch unbesuchte Zellen existieren
	 * @return true oder fals
	 */
	private boolean unvisitedCells() {
		boolean tmp=false;
		for(int i=0;i<grid.length;i++) {
			if(grid[i].isVisited()==false) {
				tmp=true;
			}
		}
		return tmp;
	}
	
	/**
	 * Liefert die Position einer Zelle in dem eindimensionalen Array
	 * @param x Spalte der Zelle
	 * @param y Zeile der Zelle
	 * @return index im Eindimensionalen Array
	 */
	private int index(int x, int y) {
		return x+y*cols;
	}
	
	/**
	 * Sucht um die Aktuelle Zelle herum alle unbesuchten Zellen und w�hlt eine zuf�llig aus.
	 * @param center Bekommt aktuelle Zelle �bergeben
	 * @return die n�chste Zelle
	 */
	private Cell findNeighbours(Cell center) {
		ArrayList<Cell> neighbours = new ArrayList<Cell>();

		if(center.getRow()==0 && center.getCol()==0) {
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			
			if(!right.isVisited()) {
				neighbours.add(right);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			
		}else if(center.getCol()==0 && center.getRow()!=0 && center.getRow()!=rows-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			
			if(!top.isVisited()) {
				neighbours.add(top);
			}
			if(!right.isVisited()) {
				neighbours.add(right);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			
		}else if(center.getCol()==0 &&  center.getRow()==rows-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			
			if(!top.isVisited()) {
				neighbours.add(top);
			}
			if(!right.isVisited()) {
				neighbours.add(right);
			}
			
		}else if(center.getRow()==0 && center.getCol()!=0 && center.getCol()!=cols-1) {
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			
			if(!left.isVisited()) {
				neighbours.add(left);
			}
			if(!right.isVisited()) {
				neighbours.add(right);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			
		}else if(center.getRow()==0 && center.getCol()==cols-1) {
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			
			if(!left.isVisited()) {
				neighbours.add(left);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			
		}else if(center.getCol()==cols-1 && center.getRow()!=0 && center.getRow()!=rows-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			
			if(!top.isVisited()) {
				neighbours.add(top);
			}
			if(!left.isVisited()) {
				neighbours.add(left);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			
		}else if(center.getCol()==cols-1 && center.getRow()==rows-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			
			if(!top.isVisited()) {
				neighbours.add(top);
			}
			if(!left.isVisited()) {
				neighbours.add(left);
			}
			
		}else if(center.getRow()==rows-1 && center.getCol()!=0 && center.getCol() != cols-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			
			if(top != null && !top.isVisited()) {
				neighbours.add(top);
			}
			if(right != null &&!right.isVisited()) {
				neighbours.add(right);
			}
			if(left != null && !left.isVisited()) {
				neighbours.add(left);
			}
			
		}else if(center.getRow()!=0 && center.getRow()!=rows-1 && center.getCol()!=0 && center.getCol()!=cols-1) {
			Cell top = grid[index(center.getCol(),((center.getRow())-1))];
			Cell right = grid[index(((center.getCol())+1),center.getRow())];
			Cell bottom = grid[index(center.getCol(),((center.getRow())+1))];
			Cell left = grid[index(((center.getCol())-1),center.getRow())];
			
			
			if(!top.isVisited()) {
				neighbours.add(top);
			}
			if(!right.isVisited()) {
				neighbours.add(right);
			}
			if(!bottom.isVisited()) {
				neighbours.add(bottom);
			}
			if(!left.isVisited()) {
				neighbours.add(left);
			}
		}
		
		if(neighbours.size()>0) {
			int rnd = (int) ((Math.random()*neighbours.size()));
			
			return neighbours.get(rnd);
		}else {
			return null;
		}
	}

	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//######################################### Ende Rekursiv Backtracker #################################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
	
	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//######################################### Begin Rekursiv Division Method ############################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
	/**
	 * Wird aus der startGeneration Methode aufgerufen
	 * 
	 * Ruft den Rekursiv Division Algorithmus auf mit der gr��e des leeren Feldes
	 */
	private void divisionRecursive() {		
		divider(0, cols, 0,rows);
	}
	
	/**
	 * Der Rekursive Division Algorithmus.
	 * Ruft sich solange selber auf mit der Gr��e eines immer kleiner werdenden Feldes bis die Zellgr��e erreicht wurde.
	 * 
	 * Teilt das Feld entweder zuf�llig horizontal oder vertikal oder entscheidet dies anhand wenn das Feld breiter oder h�her ist.
	 * 
	 * 
	 * @param colstart erste Spalte des Feldes
	 * @param colend letzte Spalte des Feldes
	 * @param rowstart erste Zeile des Feldes 
	 * @param rowend letzte Zeile des Feldes
	 */
	private void divider(int colstart, int colend, int rowstart, int rowend) {
		int tempcols=colend-colstart; //ermitteln der Breite des Feldes
		int temprows = rowend - rowstart; // ermitteln der h�he des Feldes
		int divideori = divideOrientation(tempcols, temprows); //festlegen ob horizontal oder vertikal geteilt wird
		
		if(divideori == 1) {
			int rndrow = rndNumberRange(rowstart+1, rowend-1);
			int rndcolwindow = rndNumberRange(colstart, colend-1);
			
			for(Cell c : grid) {
				if(c.getRow()==rndrow) {
					if(c.getCol()!=rndcolwindow) {
						if(c.getCol()>=colstart && c.getCol()<=colend) {
							c.setTopWall(true);
							grid[index(c.getCol(), (c.getRow()-1))].setBottomWall(true);
						}
					}
				}
			}
			
			if((rndrow-rowstart)>2 && colend-colstart>2) {
				divider(colstart, colend, rowstart, rndrow);
			}
			if((rowend-rndrow>2 && colend-colstart>2)) {
				divider(colstart, colend, rndrow, rowend);
			}
			
		}else {
			int rndcol = rndNumberRange(colstart+1, colend-1);
			int rndrowwindow = rndNumberRange(rowstart, rowend-1);
			
			for(Cell c : grid) {
				if(c.getCol()==rndcol) {
					if(c.getRow()!=rndrowwindow) {
						if(c.getRow()>=rowstart && c.getRow()<=rowend) {
							c.setLeftWall(true);
							grid[index((c.getCol()-1), c.getRow())].setRightWall(true);
						}
					}
				}
			}
			
			if((rndcol-colstart)>2 && rowend-rowstart>2) {
				divider(colstart, rndcol, rowstart, rowend);
			}
			if((colend-rndcol>2 && rowend-rowstart>2)) {
				divider(rndcol, colend, rowstart, rowend);
			}
		}	
	}
	
	/**
	 * Bestimmt ob das Feld Horizontal oder Vertikal geteilt wird 
	 * zuf�llig wenn beide gleich gro�
	 * wenn es h�her als breit ist wird es Horizontal geteilt
	 * wenn es breiter als hoch ist wird es Vertikal geteilt
	 * 
	 * @param width Breite des Feldes
	 * @param height H�he des Feldes
	 * @return 1 = horizontal | 2 = vertikal
	 */
	private int divideOrientation(int width, int height) {
		if(width<height) {
			return 1; //horizontal teilen
		}else if(height<width) {
			return 2; //vertikal teilen
		}else {
			//Beide gleich zuf�llige auswahl
			int decider = rndNumberRange(1,2);
			if(decider<=1) {
				return 1;
			}else {
				return 2;
			}
		}
	}
	
	/**
	 * Liefert Zufallszahl zwischen einem �bergebenen Min und Max wert
	 * 
	 * @param min Minimalwert
	 * @param max Maximalwert
	 * @return Zufallswert zwischen min und max (inklusive)
	 * L�sung von: Greg Case 
	 * https://stackoverflow.com/questions/363681/how-do-i-generate-random-integers-within-a-specific-range-in-java
	 * edited Jan 4 at 7:02 
	 */
	private int rndNumberRange(int min, int max) {
		if (min >= max) {
			throw new IllegalArgumentException("Minimalwert ist gr��er als Maximalwert");
		}
		return ThreadLocalRandom.current().nextInt(min, max + 1); //Max+1 damit der Maximalwert inclusive ist
	}
	
	//---------------------------------------------------------------------------------------------------------------------//
	//#####################################################################################################################//
	//######################################### Ende Rekursiv Division Method ############################################//
	//#####################################################################################################################//
	//---------------------------------------------------------------------------------------------------------------------//
	
}